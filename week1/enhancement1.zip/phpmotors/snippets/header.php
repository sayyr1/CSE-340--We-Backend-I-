<div>
        <img class="logo" src="images/site/logo.png" alt="logo_php_motors">
        <a title="Login">My Account</a>
 </div>