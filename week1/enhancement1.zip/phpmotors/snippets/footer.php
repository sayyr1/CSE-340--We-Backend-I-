<hr>
    <p class="footer">&#169; PHP Motors, All rights reserved.<br> 
    All images used are believed to be in "Fair Use". Please notify the author if any are not and thery will be removed<br>
    Last Updated: 30 March, 2018 </p>
